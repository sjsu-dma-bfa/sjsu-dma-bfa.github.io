This  will become the Exhibition Page for the Spring 2020 Graduating  DMA BFA Class

Once you have been added to the class github as a contributor:

Create a folder in this directory

Name it: your first initial your lastname

Example: rholberton

Copy the index.html code and replace the 'Hello World'  text with your name

Paste it into a file in the folder you just created called index.html

Submit the link to your index page to canvas

Example: https://sjsu-dma-bfa.github.io/2021s/rholberton/


If you don't have edit access to repo:

Double check that you provided your info in the Github Repo Signup Canvas assignment. 
Double check that you accepted the collaboration invitation from sjsu-dma-bfa. Check your spam folder of the email account you provided that is associated with your gituhub repo
 
